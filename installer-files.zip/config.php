<?php return array (
  'debug' => false,
  'database' => 
  array (
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => '000',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '000_',
    'port' => '3306',
    'strict' => false,
  ),
  'url' => 'http://localhost/000%20forum',
  'paths' => 
  array (
    'api' => 'api',
    'admin' => 'admin',
  ),
);